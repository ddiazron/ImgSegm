import numpy as np
import random
import math
from imgsegmentationmq.helpingfunctions import initialize_centroids_data

__all__ = ["means", "quantiles"]